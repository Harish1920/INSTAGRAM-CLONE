package com.instagram.Exceptions;

public class PostException extends Exception {

	public PostException(String message) {
		super(message);
	}
}
