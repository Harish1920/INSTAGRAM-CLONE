package com.instagram.Exceptions;

public class CommentException extends Exception {

	public CommentException(String message) {
		
		super(message);
	}
}
