package com.instagram.config;

public class SecurityContext {

	public static final String JWT_KEY = "qpwoeirudnfhfjsowurtthfdfnfjfmfjdjkdjskjdkjrufnckn";
	public static final String HEADER = "Authorization";
}
