package com.instagram.Exceptions;

public class StoryException extends Exception {

	public StoryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
