package com.instagram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstagramApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
