// import logo from './logo.svg';
import './App.css';
import Router from './Pages/Router/Router';

function App() {
  return (
    <div className="App">
        <Router/>
    </div>
  );
}

export default App;
